from django.contrib import admin
from .models import Vaccin

admin.site.register(Vaccin)
