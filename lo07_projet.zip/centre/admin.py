from django.contrib import admin
from .models import Centre

admin.site.register(Centre)
