from django.contrib import admin
from .models import RDV

admin.site.register(RDV)
